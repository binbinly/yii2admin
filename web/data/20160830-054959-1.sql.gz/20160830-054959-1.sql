-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- dsn     : mysql:host=localhost;dbname=yii2admin
-- 
-- Part : #1
-- Date : 2016-08-30 05:49:59
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `yii2_ad`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_ad`;
CREATE TABLE `yii2_ad` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL COMMENT '图片路径',
  `type` tinyint(3) NOT NULL COMMENT '类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转地址',
  `sort` int(5) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='图片广告';


-- -----------------------------
-- Table structure for `yii2_admin`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_admin`;
CREATE TABLE `yii2_admin` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(60) NOT NULL COMMENT '密码',
  `salt` char(32) NOT NULL COMMENT '密码干扰字符',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态 1正常 0禁用',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `yii2_admin`
-- -----------------------------
INSERT INTO `yii2_admin` VALUES ('1', 'admin', '$2y$13$YHruPeQ9VhT5LjuglzimHOqYyJf8SJitk80ADzshTjCzsb4yWcqCm', 'JSCZQ2Oh4FrAOEyPjJgIUdfbXklO6kve', 'phphome111@qq.com', '13565231111', '1457922160', '2130706433', '1457922174', '2130706433', '1467284211', '1');
INSERT INTO `yii2_admin` VALUES ('2', 'feifei', '$2y$13$jqWGlVo8T3qtnWUX0kTX/ON5ctvokzkQ7RAvKuNRjN.WvxgBlFK4u', 'tzDsmCSLbtktnvbgn1YeEqslYOBo1Cn9', 'php11111@qq.com', '13631568985', '1458028401', '2130706433', '1458028401', '2130706433', '1468230085', '1');
INSERT INTO `yii2_admin` VALUES ('4', 'testuser', '$2y$13$fac8CDeuFI7rm318MKULLexCKrk1r4jsr56MNiVshvtnZLQYBQ0dq', '30O_rRLz-fNKULFrc0OH4osPhuIzikwT', 'php2222@qq.com', '12345651111', '1459934783', '2130706433', '0', '2130706433', '1460032029', '1');
INSERT INTO `yii2_admin` VALUES ('5', 'hahaha', 'dafasfd', 'sdfas', 'phphome@qq.com', '13656856856', '0', '0', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `yii2_article`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_article`;
CREATE TABLE `yii2_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `cover` varchar(255) NOT NULL DEFAULT '' COMMENT '封面',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `content` text NOT NULL COMMENT '内容',
  `extend` text NOT NULL COMMENT '扩展内容array',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link` varchar(255) NOT NULL DEFAULT '' COMMENT '外链',
  `sort` int(4) NOT NULL DEFAULT '0' COMMENT '排序值',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='文章表';

-- -----------------------------
-- Records of `yii2_article`
-- -----------------------------
INSERT INTO `yii2_article` VALUES ('1', '2', '', '开发版发布', '/static/upload/201608/135652452.jpg', '期待已久的最新版发布', '1', '0', '2', '0', '0', '0', '1406001360', '1457924778', '1');

-- -----------------------------
-- Table structure for `yii2_auth_assignment`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_auth_assignment`;
CREATE TABLE `yii2_auth_assignment` (
  `item_name` varchar(64) NOT NULL COMMENT '角色名称 role',
  `user_id` varchar(64) NOT NULL COMMENT '用户ID',
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  CONSTRAINT `yii2_auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `yii2_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------
-- Records of `yii2_auth_assignment`
-- -----------------------------
INSERT INTO `yii2_auth_assignment` VALUES ('administrator', '2', '1545254525');
INSERT INTO `yii2_auth_assignment` VALUES ('administrator', '4', '1460012730');
INSERT INTO `yii2_auth_assignment` VALUES ('editor', '1', '1472525903');

-- -----------------------------
-- Table structure for `yii2_auth_item`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_auth_item`;
CREATE TABLE `yii2_auth_item` (
  `name` varchar(64) NOT NULL COMMENT '角色或权限名称',
  `type` int(11) NOT NULL COMMENT '1角色 2权限',
  `description` text,
  `rule_name` varchar(64) DEFAULT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `type` (`type`),
  CONSTRAINT `yii2_auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `yii2_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------
-- Records of `yii2_auth_item`
-- -----------------------------
INSERT INTO `yii2_auth_item` VALUES ('action/actionlog', '2', '', 'action/actionlog', '', '1460031880', '1460031880');
INSERT INTO `yii2_auth_item` VALUES ('action/edit', '2', '', 'action/edit', '', '1460031880', '1460031880');
INSERT INTO `yii2_auth_item` VALUES ('Addons/addHook', '2', '', 'Addons/addHook', '', '1472528088', '1472528088');
INSERT INTO `yii2_auth_item` VALUES ('Addons/adminList', '2', '', 'Addons/adminList', '', '1472528088', '1472528088');
INSERT INTO `yii2_auth_item` VALUES ('Addons/edithook', '2', '', 'Addons/edithook', '', '1472528088', '1472528088');
INSERT INTO `yii2_auth_item` VALUES ('Addons/execute', '2', '', 'Addons/execute', '', '1472528088', '1472528088');
INSERT INTO `yii2_auth_item` VALUES ('Addons/hooks', '2', '', 'Addons/hooks', '', '1472528088', '1472528088');
INSERT INTO `yii2_auth_item` VALUES ('Addons/index', '2', '', 'Addons/index', '', '1460030539', '1460030539');
INSERT INTO `yii2_auth_item` VALUES ('admin/add', '2', '', 'admin/add', '', '1472528089', '1472528089');
INSERT INTO `yii2_auth_item` VALUES ('admin/auth', '2', '', 'admin/auth', '', '1472528089', '1472528089');
INSERT INTO `yii2_auth_item` VALUES ('admin/edit', '2', '', 'admin/edit', '', '1472528089', '1472528089');
INSERT INTO `yii2_auth_item` VALUES ('admin/index', '2', '', 'admin/index', '', '1472528089', '1472528089');
INSERT INTO `yii2_auth_item` VALUES ('administrator', '1', 'administrator角色12', '', '', '1465352150', '1460005083');
INSERT INTO `yii2_auth_item` VALUES ('article/add', '2', '', 'article/add', '', '1460027926', '1460027926');
INSERT INTO `yii2_auth_item` VALUES ('article/autoSave', '2', '', 'article/autoSave', '', '1460027926', '1460027926');
INSERT INTO `yii2_auth_item` VALUES ('article/batchOperate', '2', '', 'article/batchOperate', '', '1460027926', '1460027926');
INSERT INTO `yii2_auth_item` VALUES ('article/clear', '2', '', 'article/clear', '', '1460027927', '1460027927');
INSERT INTO `yii2_auth_item` VALUES ('article/copy', '2', '', 'article/copy', '', '1460027926', '1460027926');
INSERT INTO `yii2_auth_item` VALUES ('article/edit', '2', '', 'article/edit', '', '1460027926', '1460027926');
INSERT INTO `yii2_auth_item` VALUES ('Article/examine', '2', '', 'Article/examine', '', '1460027927', '1460027927');
INSERT INTO `yii2_auth_item` VALUES ('article/index', '2', '', 'article/index', '', '1460027926', '1460027926');
INSERT INTO `yii2_auth_item` VALUES ('article/move', '2', '', 'article/move', '', '1460027926', '1460027926');
INSERT INTO `yii2_auth_item` VALUES ('article/paste', '2', '', 'article/paste', '', '1460027926', '1460027926');
INSERT INTO `yii2_auth_item` VALUES ('article/permit', '2', '', 'article/permit', '', '1460027927', '1460027927');
INSERT INTO `yii2_auth_item` VALUES ('article/recycle', '2', '', 'article/recycle', '', '1460027927', '1460027927');
INSERT INTO `yii2_auth_item` VALUES ('article/setStatus', '2', '', 'article/setStatus', '', '1460027926', '1460027926');
INSERT INTO `yii2_auth_item` VALUES ('Article/sort', '2', '', 'Article/sort', '', '1460027927', '1460027927');
INSERT INTO `yii2_auth_item` VALUES ('article/update', '2', '', 'article/update', '', '1460027926', '1460027926');
INSERT INTO `yii2_auth_item` VALUES ('attribute/add', '2', '', 'attribute/add', '', '1460031881', '1460031881');
INSERT INTO `yii2_auth_item` VALUES ('attribute/edit', '2', '', 'attribute/edit', '', '1460031881', '1460031881');
INSERT INTO `yii2_auth_item` VALUES ('attribute/index1', '2', '', 'attribute/index1', '', '1460031881', '1460031881');
INSERT INTO `yii2_auth_item` VALUES ('attribute/setStatus', '2', '', 'attribute/setStatus', '', '1460031881', '1460031881');
INSERT INTO `yii2_auth_item` VALUES ('attribute/update', '2', '', 'attribute/update', '', '1460031881', '1460031881');
INSERT INTO `yii2_auth_item` VALUES ('auth/access', '2', '', 'auth/access', '', '1460031879', '1460031879');
INSERT INTO `yii2_auth_item` VALUES ('auth/add', '2', '', 'auth/add', '', '1472528089', '1472528089');
INSERT INTO `yii2_auth_item` VALUES ('auth/addToCategory', '2', '', 'auth/addToCategory', '', '1460031880', '1460031880');
INSERT INTO `yii2_auth_item` VALUES ('auth/addToGroup', '2', '', 'auth/addToGroup', '', '1460031880', '1460031880');
INSERT INTO `yii2_auth_item` VALUES ('auth/addToModel', '2', '', 'auth/addToModel', '', '1460031880', '1460031880');
INSERT INTO `yii2_auth_item` VALUES ('auth/auth', '2', '', 'auth/auth', '', '1460031879', '1460031879');
INSERT INTO `yii2_auth_item` VALUES ('auth/category', '2', '', 'auth/category', '', '1460031880', '1460031880');
INSERT INTO `yii2_auth_item` VALUES ('auth/changeStatus?method=deleteGroup', '2', '', 'auth/changeStatus?method=deleteGroup', '', '1460031879', '1460031879');
INSERT INTO `yii2_auth_item` VALUES ('auth/changeStatus?method=forbidGroup', '2', '', 'auth/changeStatus?method=forbidGroup', '', '1460031879', '1460031879');
INSERT INTO `yii2_auth_item` VALUES ('auth/changeStatus?method=resumeGroup', '2', '', 'auth/changeStatus?method=resumeGroup', '', '1460031879', '1460031879');
INSERT INTO `yii2_auth_item` VALUES ('auth/createGroup', '2', '', 'auth/createGroup', '', '1460031879', '1460031879');
INSERT INTO `yii2_auth_item` VALUES ('auth/delete', '2', '', 'auth/delete', '', '1472528089', '1472528089');
INSERT INTO `yii2_auth_item` VALUES ('auth/edit', '2', '', 'auth/edit', '', '1472528089', '1472528089');
INSERT INTO `yii2_auth_item` VALUES ('auth/editGroup', '2', '', 'auth/editGroup', '', '1460031879', '1460031879');
INSERT INTO `yii2_auth_item` VALUES ('auth/index', '2', '', 'auth/index', '', '1200000000', '1300000000');
INSERT INTO `yii2_auth_item` VALUES ('auth/modelauth', '2', '', 'auth/modelauth', '', '1460031880', '1460031880');
INSERT INTO `yii2_auth_item` VALUES ('auth/removeFromGroup', '2', '', 'auth/removeFromGroup', '', '1460031880', '1460031880');
INSERT INTO `yii2_auth_item` VALUES ('auth/user', '2', '', 'auth/user', '', '1460031880', '1460031880');
INSERT INTO `yii2_auth_item` VALUES ('auth/writeGroup', '2', '', 'auth/writeGroup', '', '1460031879', '1460031879');
INSERT INTO `yii2_auth_item` VALUES ('category/add', '2', '', 'category/add', '', '1460031882', '1460031882');
INSERT INTO `yii2_auth_item` VALUES ('category/edit', '2', '', 'category/edit', '', '1460031882', '1460031882');
INSERT INTO `yii2_auth_item` VALUES ('category/index', '2', '', 'category/index', '', '1460031882', '1460031882');
INSERT INTO `yii2_auth_item` VALUES ('category/operate/type/merge', '2', '', 'category/operate/type/merge', '', '1460031882', '1460031882');
INSERT INTO `yii2_auth_item` VALUES ('category/operate/type/move', '2', '', 'category/operate/type/move', '', '1460031882', '1460031882');
INSERT INTO `yii2_auth_item` VALUES ('category/remove', '2', '', 'category/remove', '', '1460031882', '1460031882');
INSERT INTO `yii2_auth_item` VALUES ('channel/add', '2', '', 'channel/add', '', '1460031884', '1460031884');
INSERT INTO `yii2_auth_item` VALUES ('channel/del', '2', '', 'channel/del', '', '1460031885', '1460031885');
INSERT INTO `yii2_auth_item` VALUES ('channel/edit', '2', '', 'channel/edit', '', '1460031884', '1460031884');
INSERT INTO `yii2_auth_item` VALUES ('channel/index', '2', '', 'channel/index', '', '1460031884', '1460031884');
INSERT INTO `yii2_auth_item` VALUES ('config/add', '2', '', 'config/add', '', '1460031883', '1460031883');
INSERT INTO `yii2_auth_item` VALUES ('config/del', '2', '', 'config/del', '', '1460031883', '1460031883');
INSERT INTO `yii2_auth_item` VALUES ('config/edit', '2', '', 'config/edit', '', '1460031883', '1460031883');
INSERT INTO `yii2_auth_item` VALUES ('config/group', '2', '', 'config/group', '', '1452653200', '1452653210');
INSERT INTO `yii2_auth_item` VALUES ('config/index', '2', '', 'config/index', '', '1452653200', '1452653210');
INSERT INTO `yii2_auth_item` VALUES ('config/save', '2', '', 'config/save', '', '1460031883', '1460031883');
INSERT INTO `yii2_auth_item` VALUES ('Config/sort', '2', '', 'Config/sort', '', '1460031884', '1460031884');
INSERT INTO `yii2_auth_item` VALUES ('database/del', '2', '', 'database/del', '', '1460031882', '1460031882');
INSERT INTO `yii2_auth_item` VALUES ('database/export', '2', '', 'database/export', '', '1460031881', '1460031881');
INSERT INTO `yii2_auth_item` VALUES ('database/import', '2', '', 'database/import', '', '1460031882', '1460031882');
INSERT INTO `yii2_auth_item` VALUES ('database/index?type=export', '2', '数据库导出', 'database/index?type=export', '', '120000000', '130000000');
INSERT INTO `yii2_auth_item` VALUES ('database/index?type=import', '2', '数据库导入', 'database/index?type=import', '', '1200000000', '1300000000');
INSERT INTO `yii2_auth_item` VALUES ('database/optimize', '2', '', 'database/optimize', '', '1460031881', '1460031881');
INSERT INTO `yii2_auth_item` VALUES ('database/repair', '2', '', 'database/repair', '', '1460031881', '1460031881');
INSERT INTO `yii2_auth_item` VALUES ('editor', '1', 'editor 网站编辑角色', '', '', '1356232000', '1400000000');
INSERT INTO `yii2_auth_item` VALUES ('index/index', '2', '', 'index/index', '', '1356542542', '1425652320');
INSERT INTO `yii2_auth_item` VALUES ('log/index', '2', '', 'log/index', '', '1472528090', '1472528090');
INSERT INTO `yii2_auth_item` VALUES ('log/view', '2', '', 'log/view', '', '1472528090', '1472528090');
INSERT INTO `yii2_auth_item` VALUES ('login/logout', '2', '', 'login/logout', '', '1356565230', '1452653210');
INSERT INTO `yii2_auth_item` VALUES ('menu/add', '2', '', 'menu/add', '', '1460031884', '1460031884');
INSERT INTO `yii2_auth_item` VALUES ('menu/edit', '2', '', 'menu/edit', '', '1460031884', '1460031884');
INSERT INTO `yii2_auth_item` VALUES ('Menu/import', '2', '', 'Menu/import', '', '1460031884', '1460031884');
INSERT INTO `yii2_auth_item` VALUES ('menu/index', '2', '', 'menu/index', '', '1452653200', '1452653210');
INSERT INTO `yii2_auth_item` VALUES ('Menu/sort', '2', '', 'Menu/sort', '', '1460031884', '1460031884');
INSERT INTO `yii2_auth_item` VALUES ('model/add', '2', '', 'model/add', '', '1460031882', '1460031882');
INSERT INTO `yii2_auth_item` VALUES ('model/edit', '2', '', 'model/edit', '', '1460031883', '1460031883');
INSERT INTO `yii2_auth_item` VALUES ('Model/generate', '2', '', 'Model/generate', '', '1460031019', '1460031019');
INSERT INTO `yii2_auth_item` VALUES ('Model/index', '2', '', 'Model/index', '', '1460031882', '1460031882');
INSERT INTO `yii2_auth_item` VALUES ('model/setStatus', '2', '', 'model/setStatus', '', '1460031883', '1460031883');
INSERT INTO `yii2_auth_item` VALUES ('model/update', '2', '', 'model/update', '', '1460031883', '1460031883');
INSERT INTO `yii2_auth_item` VALUES ('order/index', '2', '', 'order/index', '', '1472528088', '1472528088');
INSERT INTO `yii2_auth_item` VALUES ('other', '2', '', 'other', '', '1472528090', '1472528090');
INSERT INTO `yii2_auth_item` VALUES ('shop/group', '2', '', 'shop/group', '', '1472528088', '1472528088');
INSERT INTO `yii2_auth_item` VALUES ('shop/index&type=1', '2', '', 'shop/index&type=1', '', '1472528087', '1472528087');
INSERT INTO `yii2_auth_item` VALUES ('shop/index&type=2', '2', '', 'shop/index&type=2', '', '1472528087', '1472528087');
INSERT INTO `yii2_auth_item` VALUES ('shop/index&type=3', '2', '', 'shop/index&type=3', '', '1472528087', '1472528087');
INSERT INTO `yii2_auth_item` VALUES ('shop/index&type=4', '2', '', 'shop/index&type=4', '', '1472528088', '1472528088');
INSERT INTO `yii2_auth_item` VALUES ('think/add', '2', '', 'think/add', '', '1460031883', '1460031883');
INSERT INTO `yii2_auth_item` VALUES ('think/edit', '2', '', 'think/edit', '', '1460031019', '1460031019');
INSERT INTO `yii2_auth_item` VALUES ('think/lists', '2', '', 'think/lists', '', '1460031020', '1460031020');
INSERT INTO `yii2_auth_item` VALUES ('train/index', '2', '', 'train/index', '', '1472528088', '1472528088');
INSERT INTO `yii2_auth_item` VALUES ('user/action', '2', '', 'user/action', '', '1460031878', '1460031878');
INSERT INTO `yii2_auth_item` VALUES ('user/add', '2', '', 'user/add', '', '1460031878', '1460031878');
INSERT INTO `yii2_auth_item` VALUES ('user/addaction', '2', '', 'user/addaction', '', '1460031878', '1460031878');
INSERT INTO `yii2_auth_item` VALUES ('user/auth', '2', '', 'user/auth', '', '1460031878', '1460031878');
INSERT INTO `yii2_auth_item` VALUES ('User/changeStatus?method=deleteUser', '2', '', 'User/changeStatus?method=deleteUser', '', '1460031879', '1460031879');
INSERT INTO `yii2_auth_item` VALUES ('user/changeStatus?method=forbidUser', '2', '', 'user/changeStatus?method=forbidUser', '', '1460031878', '1460031878');
INSERT INTO `yii2_auth_item` VALUES ('user/changeStatus?method=resumeUser', '2', '', 'user/changeStatus?method=resumeUser', '', '1460031878', '1460031878');
INSERT INTO `yii2_auth_item` VALUES ('user/editaction', '2', '', 'user/editaction', '', '1460031878', '1460031878');
INSERT INTO `yii2_auth_item` VALUES ('user/index', '2', '', 'user/index', '', '1200000000', '1230000000');
INSERT INTO `yii2_auth_item` VALUES ('user/saveAction', '2', '', 'user/saveAction', '', '1460031878', '1460031878');
INSERT INTO `yii2_auth_item` VALUES ('user/setStatus', '2', '', 'user/setStatus', '', '1460031878', '1460031878');
INSERT INTO `yii2_auth_item` VALUES ('user/updateNickname', '2', '', 'user/updateNickname', '', '1460031881', '1460031881');
INSERT INTO `yii2_auth_item` VALUES ('user/updatePassword', '2', '', 'user/updatePassword', '', '1460031881', '1460031881');

-- -----------------------------
-- Table structure for `yii2_auth_item_child`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_auth_item_child`;
CREATE TABLE `yii2_auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `yii2_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `yii2_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `yii2_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `yii2_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------
-- Records of `yii2_auth_item_child`
-- -----------------------------
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'Addons/addHook');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'Addons/adminList');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'Addons/edithook');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'Addons/execute');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'Addons/hooks');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'admin/add');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'admin/auth');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'admin/edit');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'admin/index');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'article/add');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'article/autoSave');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'article/clear');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'article/edit');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'article/index');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'article/move');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'article/permit');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'article/recycle');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'article/setStatus');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'article/update');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'attribute/add');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'attribute/edit');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'attribute/index1');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'attribute/setStatus');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'attribute/update');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'auth/access');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'auth/add');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'auth/auth');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'auth/delete');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'auth/edit');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'auth/index');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'auth/user');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'category/add');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'category/edit');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'category/index');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'category/operate/type/merge');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'category/operate/type/move');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'category/remove');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'config/add');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'config/del');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'config/edit');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'config/group');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'config/index');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'config/save');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'Config/sort');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'database/del');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'database/export');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'database/import');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'database/index?type=export');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'database/index?type=import');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'database/optimize');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'database/repair');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'index/index');
INSERT INTO `yii2_auth_item_child` VALUES ('editor', 'index/index');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'log/index');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'log/view');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'menu/add');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'menu/edit');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'Menu/import');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'menu/index');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'Menu/sort');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'order/index');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'other');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'shop/group');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'shop/index&type=1');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'shop/index&type=2');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'shop/index&type=3');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'shop/index&type=4');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'train/index');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'user/index');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'user/updateNickname');
INSERT INTO `yii2_auth_item_child` VALUES ('administrator', 'user/updatePassword');

-- -----------------------------
-- Table structure for `yii2_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_auth_rule`;
CREATE TABLE `yii2_auth_rule` (
  `name` varchar(64) NOT NULL,
  `data` text COMMENT 'serialize后的rule对象',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------
-- Records of `yii2_auth_rule`
-- -----------------------------
INSERT INTO `yii2_auth_rule` VALUES ('action/actionlog', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:16:\"action/actionlog\";s:9:\"createdAt\";i:1460031880;s:9:\"updatedAt\";i:1460031880;}', '1460031880', '1460031880');
INSERT INTO `yii2_auth_rule` VALUES ('action/edit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"action/edit\";s:9:\"createdAt\";i:1460031880;s:9:\"updatedAt\";i:1460031880;}', '1460031880', '1460031880');
INSERT INTO `yii2_auth_rule` VALUES ('Addons/addHook', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:14:\"Addons/addHook\";s:9:\"createdAt\";i:1472528088;s:9:\"updatedAt\";i:1472528088;}', '1472528088', '1472528088');
INSERT INTO `yii2_auth_rule` VALUES ('Addons/adminList', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:16:\"Addons/adminList\";s:9:\"createdAt\";i:1472528088;s:9:\"updatedAt\";i:1472528088;}', '1472528088', '1472528088');
INSERT INTO `yii2_auth_rule` VALUES ('Addons/edithook', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"Addons/edithook\";s:9:\"createdAt\";i:1472528088;s:9:\"updatedAt\";i:1472528088;}', '1472528088', '1472528088');
INSERT INTO `yii2_auth_rule` VALUES ('Addons/execute', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:14:\"Addons/execute\";s:9:\"createdAt\";i:1472528088;s:9:\"updatedAt\";i:1472528088;}', '1472528088', '1472528088');
INSERT INTO `yii2_auth_rule` VALUES ('Addons/hooks', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"Addons/hooks\";s:9:\"createdAt\";i:1472528088;s:9:\"updatedAt\";i:1472528088;}', '1472528088', '1472528088');
INSERT INTO `yii2_auth_rule` VALUES ('Addons/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"Addons/index\";s:9:\"createdAt\";i:1460030539;s:9:\"updatedAt\";i:1460030539;}', '1460030539', '1460030539');
INSERT INTO `yii2_auth_rule` VALUES ('admin/add', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:9:\"admin/add\";s:9:\"createdAt\";i:1472528089;s:9:\"updatedAt\";i:1472528089;}', '1472528089', '1472528089');
INSERT INTO `yii2_auth_rule` VALUES ('admin/auth', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:10:\"admin/auth\";s:9:\"createdAt\";i:1472528089;s:9:\"updatedAt\";i:1472528089;}', '1472528089', '1472528089');
INSERT INTO `yii2_auth_rule` VALUES ('admin/edit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:10:\"admin/edit\";s:9:\"createdAt\";i:1472528089;s:9:\"updatedAt\";i:1472528089;}', '1472528089', '1472528089');
INSERT INTO `yii2_auth_rule` VALUES ('admin/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"admin/index\";s:9:\"createdAt\";i:1472528089;s:9:\"updatedAt\";i:1472528089;}', '1472528089', '1472528089');
INSERT INTO `yii2_auth_rule` VALUES ('article/add', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"article/add\";s:9:\"createdAt\";i:1460027926;s:9:\"updatedAt\";i:1460027926;}', '1460027926', '1460027926');
INSERT INTO `yii2_auth_rule` VALUES ('article/autoSave', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:16:\"article/autoSave\";s:9:\"createdAt\";i:1460027926;s:9:\"updatedAt\";i:1460027926;}', '1460027926', '1460027926');
INSERT INTO `yii2_auth_rule` VALUES ('article/batchOperate', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:20:\"article/batchOperate\";s:9:\"createdAt\";i:1460027926;s:9:\"updatedAt\";i:1460027926;}', '1460027926', '1460027926');
INSERT INTO `yii2_auth_rule` VALUES ('article/clear', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:13:\"article/clear\";s:9:\"createdAt\";i:1460027927;s:9:\"updatedAt\";i:1460027927;}', '1460027927', '1460027927');
INSERT INTO `yii2_auth_rule` VALUES ('article/copy', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"article/copy\";s:9:\"createdAt\";i:1460027926;s:9:\"updatedAt\";i:1460027926;}', '1460027926', '1460027926');
INSERT INTO `yii2_auth_rule` VALUES ('article/edit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"article/edit\";s:9:\"createdAt\";i:1460027926;s:9:\"updatedAt\";i:1460027926;}', '1460027926', '1460027926');
INSERT INTO `yii2_auth_rule` VALUES ('Article/examine', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"Article/examine\";s:9:\"createdAt\";i:1460027927;s:9:\"updatedAt\";i:1460027927;}', '1460027927', '1460027927');
INSERT INTO `yii2_auth_rule` VALUES ('article/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:13:\"article/index\";s:9:\"createdAt\";i:1460027926;s:9:\"updatedAt\";i:1460027926;}', '1460027926', '1460027926');
INSERT INTO `yii2_auth_rule` VALUES ('article/move', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"article/move\";s:9:\"createdAt\";i:1460027926;s:9:\"updatedAt\";i:1460027926;}', '1460027926', '1460027926');
INSERT INTO `yii2_auth_rule` VALUES ('article/paste', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:13:\"article/paste\";s:9:\"createdAt\";i:1460027926;s:9:\"updatedAt\";i:1460027926;}', '1460027926', '1460027926');
INSERT INTO `yii2_auth_rule` VALUES ('article/permit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:14:\"article/permit\";s:9:\"createdAt\";i:1460027927;s:9:\"updatedAt\";i:1460027927;}', '1460027927', '1460027927');
INSERT INTO `yii2_auth_rule` VALUES ('article/recycle', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"article/recycle\";s:9:\"createdAt\";i:1460027927;s:9:\"updatedAt\";i:1460027927;}', '1460027927', '1460027927');
INSERT INTO `yii2_auth_rule` VALUES ('article/setStatus', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:17:\"article/setStatus\";s:9:\"createdAt\";i:1460027926;s:9:\"updatedAt\";i:1460027926;}', '1460027926', '1460027926');
INSERT INTO `yii2_auth_rule` VALUES ('Article/sort', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"Article/sort\";s:9:\"createdAt\";i:1460027927;s:9:\"updatedAt\";i:1460027927;}', '1460027927', '1460027927');
INSERT INTO `yii2_auth_rule` VALUES ('article/update', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:14:\"article/update\";s:9:\"createdAt\";i:1460027926;s:9:\"updatedAt\";i:1460027926;}', '1460027926', '1460027926');
INSERT INTO `yii2_auth_rule` VALUES ('attribute/add', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:13:\"attribute/add\";s:9:\"createdAt\";i:1460031881;s:9:\"updatedAt\";i:1460031881;}', '1460031881', '1460031881');
INSERT INTO `yii2_auth_rule` VALUES ('attribute/edit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:14:\"attribute/edit\";s:9:\"createdAt\";i:1460031881;s:9:\"updatedAt\";i:1460031881;}', '1460031881', '1460031881');
INSERT INTO `yii2_auth_rule` VALUES ('attribute/index1', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:16:\"attribute/index1\";s:9:\"createdAt\";i:1460031881;s:9:\"updatedAt\";i:1460031881;}', '1460031881', '1460031881');
INSERT INTO `yii2_auth_rule` VALUES ('attribute/setStatus', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:19:\"attribute/setStatus\";s:9:\"createdAt\";i:1460031881;s:9:\"updatedAt\";i:1460031881;}', '1460031881', '1460031881');
INSERT INTO `yii2_auth_rule` VALUES ('attribute/update', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:16:\"attribute/update\";s:9:\"createdAt\";i:1460031881;s:9:\"updatedAt\";i:1460031881;}', '1460031881', '1460031881');
INSERT INTO `yii2_auth_rule` VALUES ('auth/access', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"auth/access\";s:9:\"createdAt\";i:1460031879;s:9:\"updatedAt\";i:1460031879;}', '1460031879', '1460031879');
INSERT INTO `yii2_auth_rule` VALUES ('auth/add', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:8:\"auth/add\";s:9:\"createdAt\";i:1472528089;s:9:\"updatedAt\";i:1472528089;}', '1472528089', '1472528089');
INSERT INTO `yii2_auth_rule` VALUES ('auth/addToCategory', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:18:\"auth/addToCategory\";s:9:\"createdAt\";i:1460031880;s:9:\"updatedAt\";i:1460031880;}', '1460031880', '1460031880');
INSERT INTO `yii2_auth_rule` VALUES ('auth/addToGroup', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"auth/addToGroup\";s:9:\"createdAt\";i:1460031880;s:9:\"updatedAt\";i:1460031880;}', '1460031880', '1460031880');
INSERT INTO `yii2_auth_rule` VALUES ('auth/addToModel', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"auth/addToModel\";s:9:\"createdAt\";i:1460031880;s:9:\"updatedAt\";i:1460031880;}', '1460031880', '1460031880');
INSERT INTO `yii2_auth_rule` VALUES ('auth/auth', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:9:\"auth/auth\";s:9:\"createdAt\";i:1460031879;s:9:\"updatedAt\";i:1460031879;}', '1460031879', '1460031879');
INSERT INTO `yii2_auth_rule` VALUES ('auth/category', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:13:\"auth/category\";s:9:\"createdAt\";i:1460031880;s:9:\"updatedAt\";i:1460031880;}', '1460031880', '1460031880');
INSERT INTO `yii2_auth_rule` VALUES ('auth/changeStatus?method=deleteGroup', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:36:\"auth/changeStatus?method=deleteGroup\";s:9:\"createdAt\";i:1460031879;s:9:\"updatedAt\";i:1460031879;}', '1460031879', '1460031879');
INSERT INTO `yii2_auth_rule` VALUES ('auth/changeStatus?method=forbidGroup', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:36:\"auth/changeStatus?method=forbidGroup\";s:9:\"createdAt\";i:1460031879;s:9:\"updatedAt\";i:1460031879;}', '1460031879', '1460031879');
INSERT INTO `yii2_auth_rule` VALUES ('auth/changeStatus?method=resumeGroup', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:36:\"auth/changeStatus?method=resumeGroup\";s:9:\"createdAt\";i:1460031879;s:9:\"updatedAt\";i:1460031879;}', '1460031879', '1460031879');
INSERT INTO `yii2_auth_rule` VALUES ('auth/createGroup', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:16:\"auth/createGroup\";s:9:\"createdAt\";i:1460031879;s:9:\"updatedAt\";i:1460031879;}', '1460031879', '1460031879');
INSERT INTO `yii2_auth_rule` VALUES ('auth/delete', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"auth/delete\";s:9:\"createdAt\";i:1472528089;s:9:\"updatedAt\";i:1472528089;}', '1472528089', '1472528089');
INSERT INTO `yii2_auth_rule` VALUES ('auth/edit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:9:\"auth/edit\";s:9:\"createdAt\";i:1472528089;s:9:\"updatedAt\";i:1472528089;}', '1472528089', '1472528089');
INSERT INTO `yii2_auth_rule` VALUES ('auth/editGroup', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:14:\"auth/editGroup\";s:9:\"createdAt\";i:1460031879;s:9:\"updatedAt\";i:1460031879;}', '1460031879', '1460031879');
INSERT INTO `yii2_auth_rule` VALUES ('auth/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:10:\"auth/index\";s:9:\"createdAt\";i:1459148617;s:9:\"updatedAt\";i:1459148627;}', '1456542110', '1456542120');
INSERT INTO `yii2_auth_rule` VALUES ('auth/modelauth', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:14:\"auth/modelauth\";s:9:\"createdAt\";i:1460031880;s:9:\"updatedAt\";i:1460031880;}', '1460031880', '1460031880');
INSERT INTO `yii2_auth_rule` VALUES ('auth/removeFromGroup', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:20:\"auth/removeFromGroup\";s:9:\"createdAt\";i:1460031880;s:9:\"updatedAt\";i:1460031880;}', '1460031880', '1460031880');
INSERT INTO `yii2_auth_rule` VALUES ('auth/user', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:9:\"auth/user\";s:9:\"createdAt\";i:1460031880;s:9:\"updatedAt\";i:1460031880;}', '1460031880', '1460031880');
INSERT INTO `yii2_auth_rule` VALUES ('auth/writeGroup', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"auth/writeGroup\";s:9:\"createdAt\";i:1460031879;s:9:\"updatedAt\";i:1460031879;}', '1460031879', '1460031879');
INSERT INTO `yii2_auth_rule` VALUES ('category/add', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"category/add\";s:9:\"createdAt\";i:1460031882;s:9:\"updatedAt\";i:1460031882;}', '1460031882', '1460031882');
INSERT INTO `yii2_auth_rule` VALUES ('category/edit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:13:\"category/edit\";s:9:\"createdAt\";i:1460031882;s:9:\"updatedAt\";i:1460031882;}', '1460031882', '1460031882');
INSERT INTO `yii2_auth_rule` VALUES ('category/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:14:\"category/index\";s:9:\"createdAt\";i:1460031882;s:9:\"updatedAt\";i:1460031882;}', '1460031882', '1460031882');
INSERT INTO `yii2_auth_rule` VALUES ('category/operate/type/merge', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:27:\"category/operate/type/merge\";s:9:\"createdAt\";i:1460031882;s:9:\"updatedAt\";i:1460031882;}', '1460031882', '1460031882');
INSERT INTO `yii2_auth_rule` VALUES ('category/operate/type/move', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:26:\"category/operate/type/move\";s:9:\"createdAt\";i:1460031882;s:9:\"updatedAt\";i:1460031882;}', '1460031882', '1460031882');
INSERT INTO `yii2_auth_rule` VALUES ('category/remove', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"category/remove\";s:9:\"createdAt\";i:1460031882;s:9:\"updatedAt\";i:1460031882;}', '1460031882', '1460031882');
INSERT INTO `yii2_auth_rule` VALUES ('channel/add', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"channel/add\";s:9:\"createdAt\";i:1460031884;s:9:\"updatedAt\";i:1460031884;}', '1460031884', '1460031884');
INSERT INTO `yii2_auth_rule` VALUES ('channel/del', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"channel/del\";s:9:\"createdAt\";i:1460031884;s:9:\"updatedAt\";i:1460031884;}', '1460031884', '1460031884');
INSERT INTO `yii2_auth_rule` VALUES ('channel/edit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"channel/edit\";s:9:\"createdAt\";i:1460031884;s:9:\"updatedAt\";i:1460031884;}', '1460031884', '1460031884');
INSERT INTO `yii2_auth_rule` VALUES ('channel/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:13:\"channel/index\";s:9:\"createdAt\";i:1460031884;s:9:\"updatedAt\";i:1460031884;}', '1460031884', '1460031884');
INSERT INTO `yii2_auth_rule` VALUES ('config/add', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:10:\"config/add\";s:9:\"createdAt\";i:1460031883;s:9:\"updatedAt\";i:1460031883;}', '1460031883', '1460031883');
INSERT INTO `yii2_auth_rule` VALUES ('config/del', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:10:\"config/del\";s:9:\"createdAt\";i:1460031883;s:9:\"updatedAt\";i:1460031883;}', '1460031883', '1460031883');
INSERT INTO `yii2_auth_rule` VALUES ('config/edit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"config/edit\";s:9:\"createdAt\";i:1460031883;s:9:\"updatedAt\";i:1460031883;}', '1460031883', '1460031883');
INSERT INTO `yii2_auth_rule` VALUES ('config/group', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"config/group\";s:9:\"createdAt\";i:1459148617;s:9:\"updatedAt\";i:1459148627;}', '1200000000', '1300000000');
INSERT INTO `yii2_auth_rule` VALUES ('config/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"config/index\";s:9:\"createdAt\";i:1459148617;s:9:\"updatedAt\";i:1459148627;}', '1200000000', '1300000000');
INSERT INTO `yii2_auth_rule` VALUES ('config/save', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"config/save\";s:9:\"createdAt\";i:1460031883;s:9:\"updatedAt\";i:1460031883;}', '1460031883', '1460031883');
INSERT INTO `yii2_auth_rule` VALUES ('Config/sort', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"Config/sort\";s:9:\"createdAt\";i:1460031884;s:9:\"updatedAt\";i:1460031884;}', '1460031884', '1460031884');
INSERT INTO `yii2_auth_rule` VALUES ('database/del', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"database/del\";s:9:\"createdAt\";i:1460031882;s:9:\"updatedAt\";i:1460031882;}', '1460031882', '1460031882');
INSERT INTO `yii2_auth_rule` VALUES ('database/export', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"database/export\";s:9:\"createdAt\";i:1460031881;s:9:\"updatedAt\";i:1460031881;}', '1460031881', '1460031881');
INSERT INTO `yii2_auth_rule` VALUES ('database/import', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"database/import\";s:9:\"createdAt\";i:1460031882;s:9:\"updatedAt\";i:1460031882;}', '1460031882', '1460031882');
INSERT INTO `yii2_auth_rule` VALUES ('database/index?type=export', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:26:\"database/index?type=export\";s:9:\"createdAt\";i:1459148617;s:9:\"updatedAt\";i:1459148627;}', '1456542110', '1456542120');
INSERT INTO `yii2_auth_rule` VALUES ('database/index?type=import', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:26:\"database/index?type=import\";s:9:\"createdAt\";i:1459148617;s:9:\"updatedAt\";i:1459148627;}', '1456542110', '1456542120');
INSERT INTO `yii2_auth_rule` VALUES ('database/optimize', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:17:\"database/optimize\";s:9:\"createdAt\";i:1460031881;s:9:\"updatedAt\";i:1460031881;}', '1460031881', '1460031881');
INSERT INTO `yii2_auth_rule` VALUES ('database/repair', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"database/repair\";s:9:\"createdAt\";i:1460031881;s:9:\"updatedAt\";i:1460031881;}', '1460031881', '1460031881');
INSERT INTO `yii2_auth_rule` VALUES ('index/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"index/index\";s:9:\"createdAt\";i:1459148617;s:9:\"updatedAt\";i:1459148627;}', '1456542110', '1456542120');
INSERT INTO `yii2_auth_rule` VALUES ('log/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:9:\"log/index\";s:9:\"createdAt\";i:1472528090;s:9:\"updatedAt\";i:1472528090;}', '1472528090', '1472528090');
INSERT INTO `yii2_auth_rule` VALUES ('log/view', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:8:\"log/view\";s:9:\"createdAt\";i:1472528090;s:9:\"updatedAt\";i:1472528090;}', '1472528090', '1472528090');
INSERT INTO `yii2_auth_rule` VALUES ('login/logout', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"login/logout\";s:9:\"createdAt\";i:1459148665;s:9:\"updatedAt\";i:1459148675;}', '1456542110', '1456542120');
INSERT INTO `yii2_auth_rule` VALUES ('menu/add', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:8:\"menu/add\";s:9:\"createdAt\";i:1460031884;s:9:\"updatedAt\";i:1460031884;}', '1460031884', '1460031884');
INSERT INTO `yii2_auth_rule` VALUES ('menu/edit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:9:\"menu/edit\";s:9:\"createdAt\";i:1460031884;s:9:\"updatedAt\";i:1460031884;}', '1460031884', '1460031884');
INSERT INTO `yii2_auth_rule` VALUES ('Menu/import', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"Menu/import\";s:9:\"createdAt\";i:1460031884;s:9:\"updatedAt\";i:1460031884;}', '1460031884', '1460031884');
INSERT INTO `yii2_auth_rule` VALUES ('menu/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:10:\"menu/index\";s:9:\"createdAt\";i:1459148617;s:9:\"updatedAt\";i:1459148627;}', '1200000000', '1300000000');
INSERT INTO `yii2_auth_rule` VALUES ('Menu/sort', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:9:\"Menu/sort\";s:9:\"createdAt\";i:1460031884;s:9:\"updatedAt\";i:1460031884;}', '1460031884', '1460031884');
INSERT INTO `yii2_auth_rule` VALUES ('model/add', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:9:\"model/add\";s:9:\"createdAt\";i:1460031882;s:9:\"updatedAt\";i:1460031882;}', '1460031882', '1460031882');
INSERT INTO `yii2_auth_rule` VALUES ('model/edit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:10:\"model/edit\";s:9:\"createdAt\";i:1460031883;s:9:\"updatedAt\";i:1460031883;}', '1460031883', '1460031883');
INSERT INTO `yii2_auth_rule` VALUES ('Model/generate', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:14:\"Model/generate\";s:9:\"createdAt\";i:1460031019;s:9:\"updatedAt\";i:1460031019;}', '1460031019', '1460031019');
INSERT INTO `yii2_auth_rule` VALUES ('Model/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"Model/index\";s:9:\"createdAt\";i:1460031882;s:9:\"updatedAt\";i:1460031882;}', '1460031882', '1460031882');
INSERT INTO `yii2_auth_rule` VALUES ('model/setStatus', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"model/setStatus\";s:9:\"createdAt\";i:1460031883;s:9:\"updatedAt\";i:1460031883;}', '1460031883', '1460031883');
INSERT INTO `yii2_auth_rule` VALUES ('model/update', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:12:\"model/update\";s:9:\"createdAt\";i:1460031883;s:9:\"updatedAt\";i:1460031883;}', '1460031883', '1460031883');
INSERT INTO `yii2_auth_rule` VALUES ('order/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"order/index\";s:9:\"createdAt\";i:1472528088;s:9:\"updatedAt\";i:1472528088;}', '1472528088', '1472528088');
INSERT INTO `yii2_auth_rule` VALUES ('other', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:5:\"other\";s:9:\"createdAt\";i:1472528090;s:9:\"updatedAt\";i:1472528090;}', '1472528090', '1472528090');
INSERT INTO `yii2_auth_rule` VALUES ('shop/group', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:10:\"shop/group\";s:9:\"createdAt\";i:1472528088;s:9:\"updatedAt\";i:1472528088;}', '1472528088', '1472528088');
INSERT INTO `yii2_auth_rule` VALUES ('shop/index&type=1', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:17:\"shop/index&type=1\";s:9:\"createdAt\";i:1472528087;s:9:\"updatedAt\";i:1472528087;}', '1472528087', '1472528087');
INSERT INTO `yii2_auth_rule` VALUES ('shop/index&type=2', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:17:\"shop/index&type=2\";s:9:\"createdAt\";i:1472528087;s:9:\"updatedAt\";i:1472528087;}', '1472528087', '1472528087');
INSERT INTO `yii2_auth_rule` VALUES ('shop/index&type=3', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:17:\"shop/index&type=3\";s:9:\"createdAt\";i:1472528087;s:9:\"updatedAt\";i:1472528087;}', '1472528087', '1472528087');
INSERT INTO `yii2_auth_rule` VALUES ('shop/index&type=4', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:17:\"shop/index&type=4\";s:9:\"createdAt\";i:1472528088;s:9:\"updatedAt\";i:1472528088;}', '1472528088', '1472528088');
INSERT INTO `yii2_auth_rule` VALUES ('think/add', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:9:\"think/add\";s:9:\"createdAt\";i:1460031883;s:9:\"updatedAt\";i:1460031883;}', '1460031883', '1460031883');
INSERT INTO `yii2_auth_rule` VALUES ('think/edit', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:10:\"think/edit\";s:9:\"createdAt\";i:1460031019;s:9:\"updatedAt\";i:1460031019;}', '1460031019', '1460031019');
INSERT INTO `yii2_auth_rule` VALUES ('think/lists', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"think/lists\";s:9:\"createdAt\";i:1460031020;s:9:\"updatedAt\";i:1460031020;}', '1460031020', '1460031020');
INSERT INTO `yii2_auth_rule` VALUES ('train/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"train/index\";s:9:\"createdAt\";i:1472528088;s:9:\"updatedAt\";i:1472528088;}', '1472528088', '1472528088');
INSERT INTO `yii2_auth_rule` VALUES ('user/action', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:11:\"user/action\";s:9:\"createdAt\";i:1460031878;s:9:\"updatedAt\";i:1460031878;}', '1460031878', '1460031878');
INSERT INTO `yii2_auth_rule` VALUES ('user/add', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:8:\"user/add\";s:9:\"createdAt\";i:1460031877;s:9:\"updatedAt\";i:1460031877;}', '1460031877', '1460031877');
INSERT INTO `yii2_auth_rule` VALUES ('user/addaction', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:14:\"user/addaction\";s:9:\"createdAt\";i:1460031878;s:9:\"updatedAt\";i:1460031878;}', '1460031878', '1460031878');
INSERT INTO `yii2_auth_rule` VALUES ('user/auth', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:9:\"user/auth\";s:9:\"createdAt\";i:1460031878;s:9:\"updatedAt\";i:1460031878;}', '1460031878', '1460031878');
INSERT INTO `yii2_auth_rule` VALUES ('User/changeStatus?method=deleteUser', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:35:\"User/changeStatus?method=deleteUser\";s:9:\"createdAt\";i:1460031879;s:9:\"updatedAt\";i:1460031879;}', '1460031879', '1460031879');
INSERT INTO `yii2_auth_rule` VALUES ('user/changeStatus?method=forbidUser', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:35:\"user/changeStatus?method=forbidUser\";s:9:\"createdAt\";i:1460031878;s:9:\"updatedAt\";i:1460031878;}', '1460031878', '1460031878');
INSERT INTO `yii2_auth_rule` VALUES ('user/changeStatus?method=resumeUser', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:35:\"user/changeStatus?method=resumeUser\";s:9:\"createdAt\";i:1460031878;s:9:\"updatedAt\";i:1460031878;}', '1460031878', '1460031878');
INSERT INTO `yii2_auth_rule` VALUES ('user/editaction', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"user/editaction\";s:9:\"createdAt\";i:1460031878;s:9:\"updatedAt\";i:1460031878;}', '1460031878', '1460031878');
INSERT INTO `yii2_auth_rule` VALUES ('user/index', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:10:\"user/index\";s:9:\"createdAt\";i:1459148617;s:9:\"updatedAt\";i:1459148627;}', '1456542110', '1456542120');
INSERT INTO `yii2_auth_rule` VALUES ('user/saveAction', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:15:\"user/saveAction\";s:9:\"createdAt\";i:1460031878;s:9:\"updatedAt\";i:1460031878;}', '1460031878', '1460031878');
INSERT INTO `yii2_auth_rule` VALUES ('user/setStatus', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:14:\"user/setStatus\";s:9:\"createdAt\";i:1460031878;s:9:\"updatedAt\";i:1460031878;}', '1460031878', '1460031878');
INSERT INTO `yii2_auth_rule` VALUES ('user/updateNickname', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:19:\"user/updateNickname\";s:9:\"createdAt\";i:1460031881;s:9:\"updatedAt\";i:1460031881;}', '1460031881', '1460031881');
INSERT INTO `yii2_auth_rule` VALUES ('user/updatePassword', 'O:21:\"common\\core\\rbac\\Rule\":3:{s:4:\"name\";s:19:\"user/updatePassword\";s:9:\"createdAt\";i:1460031880;s:9:\"updatedAt\";i:1460031880;}', '1460031880', '1460031880');

-- -----------------------------
-- Table structure for `yii2_category`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_category`;
CREATE TABLE `yii2_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `link` varchar(250) DEFAULT '' COMMENT '外链',
  `extend` text COMMENT '扩展设置',
  `meta_title` varchar(50) DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `yii2_category`
-- -----------------------------
INSERT INTO `yii2_category` VALUES ('1', '0', 'blog', '博客', '0', '', '', '', '', '1379474947', '1382701539', '0', '1');
INSERT INTO `yii2_category` VALUES ('2', '1', 'default_blog', '默认分类', '0', '', '', '', '', '1379475028', '1471948054', '4', '1');
INSERT INTO `yii2_category` VALUES ('3', '0', 'test', '测试栏目', '', 'a:2:{s:2:\"sd\";s:2:\"11\";s:4:\"sdfs\";s:3:\"222\";}', '测试标题', '测试seo关键词', '测试描述', '1471947194', '1471948032', '1', '1');

-- -----------------------------
-- Table structure for `yii2_config`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_config`;
CREATE TABLE `yii2_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `value` text COMMENT '配置值',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yii2_config`
-- -----------------------------
INSERT INTO `yii2_config` VALUES ('1', 'WEB_SITE_TITLE', '网站标题', '1', '1', '内容管理框架', '', '网站标题前台显示标题', '1378898976', '1472528403', '0', '1');
INSERT INTO `yii2_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '网站描述', '1', '2', '内容管理框架', '', '网站搜索引擎描述', '1378898976', '1472528403', '1', '1');
INSERT INTO `yii2_config` VALUES ('3', 'WEB_SITE_KEYWORD', '网站关键字', '1', '2', '黄龙飞11', '', '网站搜索引擎关键字', '1378898976', '1472528403', '8', '1');
INSERT INTO `yii2_config` VALUES ('4', 'WEB_SITE_CLOSE', '关闭站点', '4', '4', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1463024280', '1', '0');
INSERT INTO `yii2_config` VALUES ('9', 'CONFIG_TYPE_LIST', '配置类型列表', '3', '3', '0:数字
1:字符
2:文本
3:数组
4:枚举', '', '主要用于数据解析和页面表单的生成', '1378898976', '1463024244', '2', '1');
INSERT INTO `yii2_config` VALUES ('10', 'WEB_SITE_ICP', '网站备案号', '1', '1', '沪ICP备12007941号-2', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1472528403', '9', '1');
INSERT INTO `yii2_config` VALUES ('11', 'DATA_BACKUP_PATH', '数据库备份路径', '4', '1', './data/', '', '路径必须以 / 结尾', '1379053380', '1469071721', '3', '1');
INSERT INTO `yii2_config` VALUES ('12', 'DOCUMENT_DISPLAY', '文档可见性', '2', '3', '0:所有人可见
1:仅注册会员可见
2:仅管理员可见', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1463041605', '4', '1');
INSERT INTO `yii2_config` VALUES ('13', 'COLOR_STYLE', '后台色系', '1', '4', 'default_color', 'default_color:默认
blue_color:紫罗兰', '后台颜色风格', '1379122533', '1472528403', '10', '1');

-- -----------------------------
-- Table structure for `yii2_log`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_log`;
CREATE TABLE `yii2_log` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `uid` int(8) NOT NULL COMMENT '用户uid',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `controller` varchar(50) NOT NULL COMMENT '控制器',
  `action` varchar(50) NOT NULL COMMENT '动作',
  `querystring` varchar(255) NOT NULL COMMENT '查询字符串',
  `remark` varchar(255) NOT NULL COMMENT '备注',
  `ip` varchar(15) NOT NULL DEFAULT '0.0.0.0' COMMENT 'IP',
  `create_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='后台日志';

-- -----------------------------
-- Records of `yii2_log`
-- -----------------------------
INSERT INTO `yii2_log` VALUES ('1', '2', '修改菜单', 'menu', 'index', '/admin.php/menu/index?id=4', '用户修改了菜单', '192.168.0.101', '1435658950', '1');

-- -----------------------------
-- Table structure for `yii2_menu`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_menu`;
CREATE TABLE `yii2_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yii2_menu`
-- -----------------------------
INSERT INTO `yii2_menu` VALUES ('1', '首页', '0', '1', 'index/index', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('2', '内容', '0', '2', 'article/index', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('3', '文章管理', '2', '1', 'article/index', '0', '文章管理|icon-edit', '1');
INSERT INTO `yii2_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('139', '潜水管理', '2', '22', 'shop/index&type=3', '0', '商城管理|icon-glass', '1');
INSERT INTO `yii2_menu` VALUES ('13', '回收站', '2', '99', 'article/recycle', '1', '内容', '1');
INSERT INTO `yii2_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('16', '用户', '0', '4', 'admin/index', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('17', '用户信息', '16', '1', 'admin/index', '0', '后台用户|icon-user', '1');
INSERT INTO `yii2_menu` VALUES ('18', '新增用户', '17', '0', 'admin/add', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('137', '更新', '17', '0', 'admin/edit', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('144', '商城套餐', '2', '29', 'shop/group', '0', '商城管理|icon-glass', '1');
INSERT INTO `yii2_menu` VALUES ('27', '权限管理', '16', '2', 'auth/index', '0', '后台用户|icon-user', '1');
INSERT INTO `yii2_menu` VALUES ('28', '删除', '27', '0', 'auth/delete', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('29', '编辑', '27', '0', 'auth/edit', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('30', '恢复', '27', '0', 'auth/add', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('34', '授权', '27', '0', 'auth/auth', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('35', '访问授权', '27', '0', 'auth/access', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('36', '成员授权', '27', '0', 'auth/user', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('43', '订单', '0', '3', 'order/index', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('44', '订单列表', '43', '1', 'order/index', '0', '扩展|icon-cny', '1');
INSERT INTO `yii2_menu` VALUES ('143', '海钓管理', '2', '23', 'shop/index&type=4', '0', '商城管理|icon-glass', '1');
INSERT INTO `yii2_menu` VALUES ('142', '前台用户', '16', '20', 'user/index', '0', '前台用户|icon-user-md', '1');
INSERT INTO `yii2_menu` VALUES ('141', '帆船管理', '2', '21', 'shop/index&type=2', '0', '商城管理|icon-glass', '1');
INSERT INTO `yii2_menu` VALUES ('140', '培训管理', '2', '50', 'train/index', '0', '培训管理|icon-headphones', '1');
INSERT INTO `yii2_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('57', '钩子管理', '43', '2', 'Addons/hooks', '0', '扩展', '1');
INSERT INTO `yii2_menu` VALUES ('63', '属性管理', '68', '0', 'attribute/index1', '1', '', '1');
INSERT INTO `yii2_menu` VALUES ('64', '新增', '63', '0', 'attribute/add', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('65', '编辑', '63', '0', 'attribute/edit', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('66', '改变状态', '63', '0', 'attribute/setStatus', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('67', '保存数据', '63', '0', 'attribute/update', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('68', '系统', '0', '5', 'config/group', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('69', '网站设置', '68', '1', 'config/group', '0', '系统设置|icon-legal', '1');
INSERT INTO `yii2_menu` VALUES ('70', '配置管理', '68', '1', 'config/index', '0', '系统设置|icon-legal', '1');
INSERT INTO `yii2_menu` VALUES ('71', '编辑', '70', '0', 'config/edit', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('72', '删除', '70', '0', 'config/del', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('73', '新增', '70', '0', 'config/add', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('74', '保存', '70', '0', 'config/save', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('75', '菜单管理', '68', '5', 'menu/index', '0', '系统设置|icon-legal', '1');
INSERT INTO `yii2_menu` VALUES ('80', '分类管理', '2', '2', 'category/index', '0', '文章管理|icon-edit', '1');
INSERT INTO `yii2_menu` VALUES ('81', '编辑', '80', '0', 'category/edit', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('82', '新增', '80', '0', 'category/add', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('83', '删除', '80', '0', 'category/remove', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('84', '移动', '80', '0', 'category/operate/type/move', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('85', '合并', '80', '0', 'category/operate/type/merge', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('86', '备份数据库', '68', '10', 'database/index?type=export', '0', '数据备份|icon-apple', '1');
INSERT INTO `yii2_menu` VALUES ('87', '备份', '86', '0', 'database/export', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('88', '优化表', '86', '0', 'database/optimize', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('89', '修复表', '86', '0', 'database/repair', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('90', '还原数据库', '68', '11', 'database/index?type=import', '0', '数据备份|icon-apple', '1');
INSERT INTO `yii2_menu` VALUES ('91', '恢复', '90', '0', 'database/import', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('92', '删除', '90', '0', 'database/del', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('93', '其他栏目', '0', '5', 'other', '1', '', '1');
INSERT INTO `yii2_menu` VALUES ('96', '新增', '75', '0', 'menu/add', '0', '系统设置|icon-legal', '1');
INSERT INTO `yii2_menu` VALUES ('98', '编辑', '75', '0', 'menu/edit', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('106', '行为日志', '16', '30', 'log/index', '0', '用户日志|icon-check', '1');
INSERT INTO `yii2_menu` VALUES ('108', '修改密码', '16', '0', 'user/updatePassword', '1', '', '1');
INSERT INTO `yii2_menu` VALUES ('109', '修改昵称', '16', '0', 'user/updateNickname', '1', '', '1');
INSERT INTO `yii2_menu` VALUES ('110', '查看行为日志', '106', '0', 'log/view', '1', '', '1');
INSERT INTO `yii2_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '1');
INSERT INTO `yii2_menu` VALUES ('138', '酒店管理', '2', '20', 'shop/index&type=1', '0', '商城管理|icon-glass', '1');
INSERT INTO `yii2_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '1');
INSERT INTO `yii2_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '1');
INSERT INTO `yii2_menu` VALUES ('129', '用户授权', '17', '0', 'admin/auth', '0', '', '0');
INSERT INTO `yii2_menu` VALUES ('131', '待完成任务', '1', '0', 'index/index', '0', '任务列表', '0');

-- -----------------------------
-- Table structure for `yii2_order`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_order`;
CREATE TABLE `yii2_order` (
  `order_id` int(8) NOT NULL AUTO_INCREMENT,
  `order_sn` char(10) NOT NULL COMMENT '订单号',
  `uid` int(8) NOT NULL COMMENT '用户id',
  `type` char(10) NOT NULL COMMENT '订单类型 shop或train',
  `aid` int(8) NOT NULL COMMENT '商品或培训ID',
  `title` varchar(100) NOT NULL COMMENT '商品名称',
  `start_time` int(10) NOT NULL COMMENT '起租时间',
  `end_time` int(10) NOT NULL COMMENT '退租时间',
  `num` int(4) NOT NULL DEFAULT '1' COMMENT '数量',
  `pay_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态',
  `pay_time` int(10) NOT NULL COMMENT '支付时间',
  `pay_name` varchar(30) NOT NULL DEFAULT '' COMMENT '支付类型',
  `create_time` int(10) NOT NULL COMMENT '订单创建时间',
  `status` tinyint(1) NOT NULL COMMENT '状态',
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单表';


-- -----------------------------
-- Table structure for `yii2_picture`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_picture`;
CREATE TABLE `yii2_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `yii2_shop`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_shop`;
CREATE TABLE `yii2_shop` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(4) NOT NULL COMMENT '房间类型',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `images` varchar(255) NOT NULL COMMENT '图组',
  `num` int(3) NOT NULL COMMENT '房间总数量',
  `price` decimal(8,2) NOT NULL COMMENT '通常价格，格式231.02',
  `extend` text NOT NULL COMMENT '扩展数据',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='酒店表';


-- -----------------------------
-- Table structure for `yii2_shop_group`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_shop_group`;
CREATE TABLE `yii2_shop_group` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL COMMENT '套餐标题',
  `groups` varchar(100) NOT NULL COMMENT '商品组合，数字逗号分隔',
  `price` decimal(8,2) NOT NULL COMMENT '套餐价格',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='套餐设置';


-- -----------------------------
-- Table structure for `yii2_shop_price`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_shop_price`;
CREATE TABLE `yii2_shop_price` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(8) NOT NULL,
  `day` int(10) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hotel_id` (`hotel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='每日价格列表';


-- -----------------------------
-- Table structure for `yii2_shop_type`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_shop_type`;
CREATE TABLE `yii2_shop_type` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '类型名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='房间类型表';

-- -----------------------------
-- Records of `yii2_shop_type`
-- -----------------------------
INSERT INTO `yii2_shop_type` VALUES ('1', '房间');
INSERT INTO `yii2_shop_type` VALUES ('2', '帆船');
INSERT INTO `yii2_shop_type` VALUES ('3', '潜水');
INSERT INTO `yii2_shop_type` VALUES ('4', '海钓');

-- -----------------------------
-- Table structure for `yii2_train`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_train`;
CREATE TABLE `yii2_train` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL COMMENT '培训类型',
  `title` int(100) NOT NULL COMMENT '排序标题',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `price` decimal(8,2) NOT NULL COMMENT '价格',
  `num` tinyint(3) NOT NULL DEFAULT '1' COMMENT '最少人数',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='培训表';


-- -----------------------------
-- Table structure for `yii2_train_type`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_train_type`;
CREATE TABLE `yii2_train_type` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '类型名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='房间类型表';

-- -----------------------------
-- Records of `yii2_train_type`
-- -----------------------------
INSERT INTO `yii2_train_type` VALUES ('1', '一对一');
INSERT INTO `yii2_train_type` VALUES ('2', '组团');
INSERT INTO `yii2_train_type` VALUES ('3', '拼团');

-- -----------------------------
-- Table structure for `yii2_user`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_user`;
CREATE TABLE `yii2_user` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(60) NOT NULL COMMENT '密码',
  `salt` char(32) NOT NULL COMMENT '密码干扰字符',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '头像路径',
  `score` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '当前积分',
  `score_all` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '总积分',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态 1正常 0禁用',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='用户表';


-- -----------------------------
-- Table structure for `yii2_user_data`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_user_data`;
CREATE TABLE `yii2_user_data` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `yii2_user_rank`
-- -----------------------------
DROP TABLE IF EXISTS `yii2_user_rank`;
CREATE TABLE `yii2_user_rank` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL COMMENT '等级名称',
  `score` int(8) NOT NULL COMMENT '积分界限',
  `discount` decimal(6,2) NOT NULL DEFAULT '0.00' COMMENT '折扣百分比',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='会员等级配置';

-- -----------------------------
-- Records of `yii2_user_rank`
-- -----------------------------
INSERT INTO `yii2_user_rank` VALUES ('1', '普通会员', '0', '0.00', '1');
INSERT INTO `yii2_user_rank` VALUES ('2', '一级会员', '2000', '3.00', '1');
INSERT INTO `yii2_user_rank` VALUES ('3', '二级会员', '5000', '6.00', '1');
INSERT INTO `yii2_user_rank` VALUES ('4', 'VIP会员', '10000', '10.00', '1');
INSERT INTO `yii2_user_rank` VALUES ('5', '钻石会员', '100000', '20.00', '1');
